from django.apps import AppConfig


class MemoConfig(AppConfig):
    name = 'memo'
